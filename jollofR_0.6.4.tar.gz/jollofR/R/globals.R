globalVariables(
  c("starts_with", "total", "starts_with", "Age", "Gender","vars","geom_title","x","y","geom_tile",
    "Population", "Key", "admin_id", "coord_equal", "element_text", "facet_wrap", "geom_boxplot",
    "geom_histogram", "geom_line", "geom_raster", "group_by", "key", "rasterFromXYZ", "raster_files", "scale_fill_viridis_c", "scale_x_continuous",
    "summarise_at", "theme", "theme_bw", "value", "writeRaster", "vars", "stdize"
  ))

# jollofR 0.4.0

# jollofR 0.3.0

* Initial CRAN submission.
